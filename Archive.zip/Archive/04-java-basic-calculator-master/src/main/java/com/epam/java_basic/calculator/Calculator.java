package com.epam.java_basic.calculator;

public class Calculator {

    public Calculator(int precision) {


    }

    public double add(double a, double b) {
        System.out.println(a+b);
        return  a+b;

    }

    public double subtract(double a, double b) {
        System.out.println(a-b);
        return a-b;
    }

    public double multiply(double a, double b) {
        System.out.println(a*b);
        return a*b;
    }

    public double div(double a, double b) {
        System.out.println(a/b);
       return a/b;
    }

}
